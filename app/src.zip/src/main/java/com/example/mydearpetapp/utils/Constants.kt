package com.example.mydearpetapp.utils

class Constants {
    companion object{
        val KEY_PET = "key_pet"
        val KEY_CONTACTO = "key_contacto"
        val KEY_PENDIENTE = "key_pendiente"
    }
}